package com.sunilos.proj0.dao;


import java.util.List;

import com.sunilos.proj0.dto.CourseDTO;

public interface CourseDAOInt {

	/**
	 *  Add a Course
	 * @param dto
	 * @return long
	 */
	public long add(CourseDTO dto);

	/**
	 * Update a Course
	 * @param dto
	 */
	public void update(CourseDTO dto);

	/**
	 * Delete a Course
	 * @param dto
	 */
	public void delete(CourseDTO dto);

	/**
	 * Find Course by Primary Key.
	 * @param pk
	 * @return CourseDTO
	 */
	public CourseDTO findByPK(long pk);

	/**
	 * Find Course by name
	 * @param name
	 * @return CourseDTO
	 */
	public CourseDTO findByName(String name);

	/**
	 * Search Course with pagination
	 * @param dto
	 * @param pageNo
	 * @param pageSize
	 * @return
	 */
	public List<CourseDTO> search(CourseDTO dto,int pageNo,int pageSize);

	/**
	 * Search Course
	 * @param dto
	 * @return
	 */
	public List<CourseDTO> search(CourseDTO dto);

}
