package com.sunilos.proj0.dao;

import java.util.List;

import com.sunilos.proj0.dto.SubjectDTO;

/**
 * 
 * Subject DAO interface.
 * 
 * @author OB Server
 * @version 1.0
 * @Copyright (c) OB Server
 */
public interface SubjectDAOInt {

/**
 *  Add a Subject
 * @param dto
 * @return long
 */
public long add(SubjectDTO dto);

/**
 * Update a Subject
 * @param dto
 */
public void update(SubjectDTO dto);

/**
 * Delete a Subject
 * @param dto
 */
public void delete(SubjectDTO dto);

/**
 * Find Subject by Primary Key.
 * @param pk
 * @return RoleDTO
 */
public SubjectDTO findByPK(long pk);

/**
 * Find Subject by name
 * @param name
 * @return RoleDTO
 */
public SubjectDTO findByName(String name);

/**
 * Search Subject with pagination
 * @param dto
 * @param pageNo
 * @param pageSize
 * @return
 */
public List<SubjectDTO> search(SubjectDTO dto,int pageNo,int pageSize);

/**
 * Search Role
 * @param dto
 * @return
 */
public List<SubjectDTO> search(SubjectDTO dto);
}

