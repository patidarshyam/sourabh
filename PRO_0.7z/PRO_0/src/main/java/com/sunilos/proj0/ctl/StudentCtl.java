package com.sunilos.proj0.ctl;

import java.util.List;
import java.util.Locale;

import javax.validation.Valid;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.sunilos.proj0.dto.RoleDTO;
import com.sunilos.proj0.dto.StudentDTO;
import com.sunilos.proj0.exception.RecordNotFoundException;
import com.sunilos.proj0.form.RoleForm;
import com.sunilos.proj0.form.StudentForm;
import com.sunilos.proj0.service.CollegeServiceInt;
import com.sunilos.proj0.service.StudentServiceInt;

/**
 * Contains navigation logics for Student and Student List usecases.
 * 
 * @author OB Server
 * @version 1.0
 * @Copyright (c) OB Server
 */

@Controller
@RequestMapping(value="/ctl/Student")
public class StudentCtl extends BaseCtl{

	/**
     * Logger object
     */
	private static Logger log=Logger.getLogger(StudentCtl.class);
	
	@Autowired
	StudentServiceInt service;
	
	@Autowired
	CollegeServiceInt collegeService;
	
	@Autowired
	MessageSource messageSource;
	
	/**
     * Preload Student List
     */
	@Override
	public void preload(Model model) {
		
		log.debug("StudentCtl preload start");
		
		System.out.println("Preload method of StudentCtl");
		List list=collegeService.search(null);
		model.addAttribute("collegeList", list);
		
		List list1=service.search(null, 0, 0);
		model.addAttribute("studentList", list1);
		log.debug("StudentCtl preload End");
	}
	
	/**
	 * Student Display View
	 * 
	 * @param id
	 * @param form
	 * @param model
	 * @return
	 */
	@RequestMapping(method=RequestMethod.GET)
	public String display(@RequestParam(required=false) Long id, @ModelAttribute("form") StudentForm form,Model model)
	{
		log.debug("StudentCtl display start");
		
		if(id!=null && id>0)
		{
			try 
			{
				StudentDTO dto=service.findByPK(id);
				form.populate(dto);
				
			} catch (RecordNotFoundException e) {
				
			  log.error("Critical issue",e);
				e.printStackTrace();
				
			}
		}
		log.debug("StudentCtl display End");
		return "Student";
	}
	
	/**
	 *Student Submit View
	 * 
	 * @param locale
	 * @param operation
	 * @param form
	 * @param bindingResult
	 * @param model
	 * @return
	 */
	
	@RequestMapping(method=RequestMethod.POST)
	public String submit(Locale locale,@RequestParam String operation,
		@ModelAttribute("form") @Valid StudentForm form,BindingResult bindingResult,Model model	)
	{
		log.debug("StudentCtl Submit start");
		
		if(OP_RESET.equalsIgnoreCase(operation))
		{
			return "redirect:/ctl/Student";
		}
		if(OP_CANCEL.equalsIgnoreCase(form.getOperation()))
        {
     	   return "redirect:/ctl/Student/search";
        }
		if(bindingResult.hasErrors())
		{
			return "Student";
		}
		
		try
		{
		if(OP_SAVE.equalsIgnoreCase(operation) || OP_UPDATE.equalsIgnoreCase(operation))
		{
			StudentDTO dto=(StudentDTO)form.getDto();
			/*System.out.println("------------"+dto.getCollegeId());
			System.out.println("+++++++++++"+dto.getCollegeName());*/
			if(dto.getId()>0)
			{
				service.update(dto);
			}else
			{
				long id=service.add(dto);
				/*form.setId(id);*/
			}
			String msg=messageSource.getMessage("message.success", null,locale);
			model.addAttribute("success", msg);
		}else if(OP_DELETE.equalsIgnoreCase(operation))
		{
			service.delete(form.getId());
			
			String msg = messageSource.getMessage("message.success", null,
                    locale);
            model.addAttribute("success", msg);

            return "redirect:/ctl/Student/search";
		}
		}catch(Exception e)
		{
			log.error("Critical Issue", e);
			model.addAttribute("error",""+e.getMessage());
		}
		
		log.debug("StudentCtl Submit End");
		return "Student";
	}

	 /**
     * Displays Student List view.
     * 
     * @param form
     * @param model
     * @return
     */
    @RequestMapping(value = "/search", method = RequestMethod.GET)
    public String searchList(@ModelAttribute("form") StudentForm form, Model model) {
        model.addAttribute("list",
                service.search(null, form.getPageNo(), form.getPageSize()));
        return "StudentList";
    }

    /**
     * Submits Student List data.
     * 
     * @param locale
     * @param form
     * @param operation
     * @param model
     * @return
     */
    @RequestMapping(value = "/search", method = {RequestMethod.POST })
    public String searchList(Locale locale,
            @ModelAttribute("form") StudentForm form,
            @RequestParam(required = false) String operation, Model model) {

        log.debug("in searchList method");

     
       
        // Calculate next page number
        int pageNo = form.getPageNo();

        if (OP_NEXT.equals(operation)) {
            pageNo++;
        } else if (OP_PREVIOUS.equals(operation)) {
            pageNo--;
        }

        pageNo = (pageNo < 1) ? 1 : pageNo;

        form.setPageNo(pageNo);
        if(OP_RESET.equalsIgnoreCase(form.getOperation()))
        {
     	   return "redirect:/ctl/Student/search";
        }else
             if(OP_NEW.equalsIgnoreCase(form.getOperation()))
        {
     	   return "redirect:/ctl/Student";
        }else
              if (OP_DELETE.equalsIgnoreCase(operation)) {
            
            	   if(form.getChk_1() != null)
            	  {
                       for (long id : form.getChk_1()) {
            try {
					service.delete(id);
				} catch (RecordNotFoundException e) 
                  {
					log.error("Critical Issue", e);
					e.printStackTrace();
				  }
            }

            String msg = messageSource.getMessage("message.success", null,
                    locale);
            model.addAttribute("success", msg);

        }else
        {
        	
             model.addAttribute("error", "Select Atleast One Record");	
        }
              }
        // Get search attributes
        StudentDTO dto = (StudentDTO) form.getDto();

        if(OP_DELETE.equalsIgnoreCase(operation))
        {
        	dto=null;
        }
         
        List list=service.search(dto, pageNo, form.getPageSize());
        model.addAttribute("list",list);

  		if(list.size()==0 && !OP_DELETE.equalsIgnoreCase(operation)){
  			model.addAttribute("error","No Record Found ");
  		}
        return "StudentList";
    }


}
