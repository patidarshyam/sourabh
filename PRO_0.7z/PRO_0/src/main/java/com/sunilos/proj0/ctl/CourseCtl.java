package com.sunilos.proj0.ctl;

import java.util.List;
import java.util.Locale;

import javax.validation.Valid;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.sunilos.proj0.dto.CourseDTO;
import com.sunilos.proj0.dto.RoleDTO;
import com.sunilos.proj0.exception.RecordNotFoundException;
import com.sunilos.proj0.form.CourseForm;
import com.sunilos.proj0.form.RoleForm;
import com.sunilos.proj0.service.CourseServiceInt;

/**
 * Contains navigation logics for Course and Course List usecases.
 * 
 * @author OB Server
 * @version 1.0
 * @Copyright (c) OB Server
 */
@Controller
@RequestMapping(value="/ctl/Course")

public class CourseCtl extends BaseCtl
{

	/**
     * Logger object
     */
	private static Logger log=Logger.getLogger(CourseCtl.class);
	
	/**
     * Course Service
     */
	@Autowired
	private CourseServiceInt service;
	
	/**
     * i18n Message source
     */
	@Autowired
	private MessageSource messageSource;
	
	 
    /**
     * Preload Course List
     */
	@Override
	public void preload(Model model) {
		
		log.debug("CourseCtl preload start");
		
		System.out.println("Preload method of CourseCtl");
		
		List list=service.search(null, 0, 0);
		model.addAttribute("courseList", list);
		log.debug("CourseCtl preload End");
	}
	
	/**
	 * Display Method 
	 * 
	 * @param locale
	 * @param id
	 * @param form
	 * @param model
	 * @return
	 */
	@RequestMapping(method=RequestMethod.GET)
	public String display(Locale locale,@RequestParam(required=false)Long id,@ModelAttribute("form") CourseForm form,Model model)
	{
		log.debug("CourseCtl display start");
		
		if(id!=null && id>0)
		{
			CourseDTO dto=service.findById(id);
			form.populate(dto);
		}
		log.debug("CourseCtl display End");
		return "Course";
	}
	
	/**
	 * Submit Course View
	 * 
	 * @param locale
	 * @param operation
	 * @param forms
	 * @param form
	 * @param result
	 * @param model
	 * @return
	 */
	@RequestMapping(method=RequestMethod.POST)
	public String submit(Locale locale,@RequestParam String operation,@ModelAttribute("form")
			@Valid CourseForm form,BindingResult result,Model model)
	{
		log.debug("CourseCtl submit Start");
		
		 if(OP_RESET.equalsIgnoreCase(form.getOperation()))
	        {
	     	   return "redirect:/ctl/Course";
	        }
		 if(OP_CANCEL.equalsIgnoreCase(form.getOperation()))
	        {
	     	   return "redirect:/ctl/Course/search";
	        }
		if(result.hasErrors())
		{
			return "Course";
		}
		
		CourseDTO dto=(CourseDTO)form.getDto();
		
		try
		{
		if(OP_SAVE.equalsIgnoreCase(operation)||OP_UPDATE.equalsIgnoreCase(operation))
		{
	
			if(dto.getId()>0)
			{
				service.update(dto);
			}else
			{
				service.add(dto);
			}
			String msg=messageSource.getMessage("message.success",null,locale);
			model.addAttribute("success", msg);
			
		}else if(OP_DELETE.equalsIgnoreCase(operation))
		{
			service.delete(form.getId());
			
		     String msg = messageSource.getMessage("message.success", null,
                     locale);
             model.addAttribute("success", msg);

             return "redirect:/ctl/Course/search";
		}
		
		}catch(Exception e)
		{
			 log.error(e);
	         model.addAttribute("error", " " + e.getMessage());	
		}
		log.debug("Course submit End");
		return "Course";
	}	
	
	 /**
     * Displays Course List view.
     * 
     * @param form
     * @param model
     * @return
     */
    @RequestMapping(value = "/search", method = RequestMethod.GET)
    public String searchList(@ModelAttribute("form") CourseForm form, Model model) {
        model.addAttribute("list",
                service.search(null, form.getPageNo(), form.getPageSize()));
        return "CourseList";
    }

    /**
     * Submits Course List data.
     * 
     * @param locale
     * @param form
     * @param operation
     * @param model
     * @return
     */
    @RequestMapping(value = "/search", method = {RequestMethod.POST })
    public String searchList(Locale locale,
            @ModelAttribute("form") CourseForm form,
            @RequestParam(required = false) String operation, Model model) {

        log.debug("in searchList method");

     
       
        // Calculate next page number
        int pageNo = form.getPageNo();

        if (OP_NEXT.equals(operation)) {
            pageNo++;
        } else if (OP_PREVIOUS.equals(operation)) {
            pageNo--;
        }

        pageNo = (pageNo < 1) ? 1 : pageNo;

        form.setPageNo(pageNo);
        if(OP_RESET.equalsIgnoreCase(form.getOperation()))
        {
     	   return "redirect:/ctl/Course/search";
        }else
             if(OP_NEW.equalsIgnoreCase(form.getOperation()))
        {
     	   return "redirect:/ctl/Course";
        }else
              if (OP_DELETE.equalsIgnoreCase(operation)) {
            
            	   if(form.getChk_1() != null)
            	  {
                       for (long id : form.getChk_1()) {
            try {
					service.delete(id);
				} catch (RecordNotFoundException e) 
                  {
					log.error("Critical Issue", e);
					e.printStackTrace();
				  }
            }

            String msg = messageSource.getMessage("message.success", null,
                    locale);
            model.addAttribute("success", msg);

        }else
        {
        	
             model.addAttribute("error", "Select Atleast One Record");	
        }
              }
        // Get search attributes
        CourseDTO dto = (CourseDTO) form.getDto();

        if(OP_DELETE.equalsIgnoreCase(operation))
        {
        	dto=null;
        }
         
        List list=service.search(dto, pageNo, form.getPageSize());
        model.addAttribute("list",list);

  		if(list.size()==0 && !OP_DELETE.equalsIgnoreCase(operation)){
  			model.addAttribute("error","No Record Found ");
  		}
        return "CourseList";
    }

}
