package com.sunilos.proj0.dao;

import java.util.List;

import com.sunilos.proj0.dto.CollegeDTO;

public interface CollegeDAOInt {

	/**
	 *  Add a College
	 * @param dto
	 * @return long
	 */
	public long add(CollegeDTO dto);

	/**
	 * Update a College
	 * @param dto
	 */
	public void update(CollegeDTO dto);

	/**
	 * Delete a College
	 * @param dto
	 */
	public void delete(CollegeDTO dto);

	/**
	 * Find College by Primary Key.
	 * @param pk
	 * @return CollegeDTO
	 */
	public CollegeDTO findByPK(long pk);

	/**
	 * Find College by name
	 * @param name
	 * @return CollegeDTO
	 */
	public CollegeDTO findByName(String name);

	/**
	 * Search College with pagination
	 * @param dto
	 * @param pageNo
	 * @param pageSize
	 * @return
	 */
	public List<CollegeDTO> search(CollegeDTO dto,int pageNo,int pageSize);

	/**
	 * Search College
	 * @param dto
	 * @return
	 */
	public List<CollegeDTO> search(CollegeDTO dto);

}
