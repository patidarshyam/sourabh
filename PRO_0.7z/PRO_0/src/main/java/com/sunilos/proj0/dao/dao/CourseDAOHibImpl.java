package com.sunilos.proj0.dao;

import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.sunilos.proj0.dto.CourseDTO;
/**
 * Hibernate implementation of Course DAO.
 * 
 * @author OB Server
 * @version 1.0
 * @Copyright (c) OB Server
 * 
 */

@Repository
public class CourseDAOHibImpl implements CourseDAOInt {

	@Autowired
	SessionFactory sessionFactory=null;
	
	public static Logger log=Logger.getLogger(CourseDAOHibImpl.class);
	/**
	 * Add Course
	 *
	 */
	public long add(CourseDTO dto) {
		
		log.debug("RoleDAOHibImpl add starts");
		long pk=(Long)sessionFactory.getCurrentSession().save(dto);
		log.debug("RoleDAOHibImpl add end");
		return pk;
	}
	/**
	 * Update Course
	 *
	 */
	public void update(CourseDTO dto) {
		log.debug("RoleDAOHibImpl Update starts");
		sessionFactory.getCurrentSession().merge(dto);
		log.debug("RoleDAOHibImpl Update End");
		
	}
	/**
	 *Delete Course
	 *
	 */
	public void delete(CourseDTO dto) {
		log.debug("RoleDAOHibImpl Delete starts");
		sessionFactory.getCurrentSession().delete(dto);
		log.debug("RoleDAOHibImpl Delete End");
	}
	/**
	 * find by Pk
	 *
	 */
	public CourseDTO findByPK(long pk) {
		
		log.debug("RoleDAOHibImpl findByPK starts");
		
		CourseDTO dto=null;
		dto=(CourseDTO)sessionFactory.openSession().get(CourseDTO.class, pk);
		
		log.debug("RoleDAOHibImpl findByPK End");
		return dto;
	}
	/**
	 * find Course by Name
	 *
	 */
	public CourseDTO findByName(String name) {
		log.debug("RoleDAOHibImpl findByName starts");
		
		CourseDTO dto=null;
		Criteria criteria=sessionFactory.getCurrentSession().createCriteria(CourseDTO.class);
		List list=criteria.add(Restrictions.like("courseName", name)).list();
		
		if(list.size()==1)
		{
			dto=(CourseDTO)list.get(0);
		}
		log.debug("RoleDAOHibImpl findByName End");
		return dto;
	} 
	/**
     * Search Course
     * 
     * @return list : List of Course
     * @param dto
     *            : Search Parameters
     */

	public List<CourseDTO> search(CourseDTO dto, int pageNo, int pageSize) {
		
		log.debug("RoleDAOHibImpl Search starts");
		
		Criteria criteria=sessionFactory.getCurrentSession().createCriteria(CourseDTO.class);
		
		/*if(dto.getId()>0)
		{
			criteria.add(Restrictions.eq("id", dto.getId()));
		}*/
		if(dto!=null)
		{
		if(dto.getCourseName()!=null && dto.getCourseName().length()>0)
		{
			criteria.add(Restrictions.like("courseName", dto.getCourseName()+ "%"));
		}
		if(dto.getDescription()!=null && dto.getDescription().length()>0)
		{
		   criteria.add(Restrictions.like("description", dto.getDescription()+ "%"));
		}
		if(dto.getDuration()!=null && dto.getDuration().length()>0)
		{
		   criteria.add(Restrictions.like("duration", dto.getDuration()+ "%"));
		}
		}
		if(pageSize>0)
		{
			criteria.setFirstResult((pageNo-1)*pageSize);
			criteria.setMaxResults(pageSize);
		}
		
		List<CourseDTO> list=criteria.list();
		log.debug("RoleDAOHibImpl Search End");
		return list;
	}
	  /**
     * Search Course
     * 
     * @return list : List of Course
     * @param dto
     *            : Search Parameters
     */
	public List<CourseDTO> search(CourseDTO dto) {
		
		return search(dto, 0, 0);
	}

	
}
