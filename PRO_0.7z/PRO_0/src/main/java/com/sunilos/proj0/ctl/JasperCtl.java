package com.sunilos.proj0.ctl;

import java.sql.Connection;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.hibernate.SessionFactory;
import org.hibernate.engine.jdbc.connections.spi.ConnectionProvider;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.design.JasperDesign;

/**
 * JasperCtl for Jasper Report
 *
 */

@Controller
@RequestMapping(value="/ctl/JasperCtl")
public class JasperCtl {

	@Autowired
	SessionFactory sessionFactory;
	
	public static Logger log=Logger.getLogger(JasperCtl.class);
	/**
	 * Display Jasper Report
	 *
	 */
	@RequestMapping(method=RequestMethod.GET)
	public void display(HttpServletRequest request,HttpServletResponse response)
	{
		Connection conn;
		JasperReport jasperReport;
		JasperCompileManager compileManager;
		JasperFillManager fillManager;
		JasperExportManager exportManager;
		JasperPrint print;
		log.debug("Jasper dispay Start");
		
		try
		{
		String path = request.getRealPath("/resources/Report/Marksheet.jrxml");
	
		Connection con = null;
		 jasperReport = JasperCompileManager.compileReport(path);
		Map<String, Object> map = new HashMap<String, Object>();
		
	//	con = ((SessionImpl) sessionFactory.getCurrentSession()).connection();
		 con = sessionFactory.
	                getSessionFactoryOptions().getServiceRegistry().getService(ConnectionProvider.class).getConnection();
	                
	                //getService(ConnectionProvider.class).getConnection();

		JasperPrint jasperPrint = JasperFillManager.fillReport(jasperReport, map, con);
		byte[] pdf = JasperExportManager.exportReportToPdf(jasperPrint);

		response.setContentType("application/pdf");
		response.getOutputStream().write(pdf);
		response.getOutputStream().flush();
		}catch(Exception e)
		{
			log.error(e);
			e.printStackTrace();
		}


		log.debug("Jasper dispay End");
	}
}
