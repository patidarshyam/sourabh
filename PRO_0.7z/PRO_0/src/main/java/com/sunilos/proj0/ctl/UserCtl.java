package com.sunilos.proj0.ctl;

import java.util.List;
import java.util.Locale;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.sunilos.proj0.dto.RoleDTO;
import com.sunilos.proj0.dto.UserDTO;
import com.sunilos.proj0.exception.RecordNotFoundException;
import com.sunilos.proj0.form.ChangePasswordForm;
import com.sunilos.proj0.form.MyProfileForm;
import com.sunilos.proj0.form.UserForm;
import com.sunilos.proj0.service.RoleServiceInt;
import com.sunilos.proj0.service.UserServiceInt;
import com.sunilos.proj0.util.Util;

/**
 * Contains navigation logics for User, UserList, MyProfile, ChangePassword,
 * usecases.
 * 
 * @author OB Server
 * @version 1.0
 * @Copyright (c) OB Server
 */

@Controller
@RequestMapping(value="/ctl/UserCtl")
public class UserCtl extends BaseCtl {

	private static Logger log=Logger.getLogger(UserCtl.class);
	
	@Autowired
	UserServiceInt userService;
	
	@Autowired
	RoleServiceInt roleService;
	
	@Autowired
	MessageSource messageSource;
	
	/**
     * Preload Role List
     */
	@Override
	public void preload(Model model) {
		
		log.debug("UserCtl preload start");
		
		System.out.println("Preload method of UserCtl");
		List list=roleService.search(null);
		model.addAttribute("roleList", list);
		
		List list1=userService.search(null, 0, 0);
		model.addAttribute("userList", list1);
		log.debug("UserCtl preload End");
	}
	
	/**
     * Display Data
     */
	@RequestMapping(method={RequestMethod.GET})
	public String display(@RequestParam(required=false) Long id,@ModelAttribute("form") UserForm form,Model model)
	{
		log.debug("UserCtl diplay start");
		
		preload(model);
		if(id!=null && id>0)
		{
			try {
				
				UserDTO dto=userService.findByPK(form.getId());
				form.populate(dto);
			} catch (RecordNotFoundException e) {
				log.error("Critical Issue", e);
				e.printStackTrace();
			}
		}
		
		log.debug("UserCtl diplay End");
		return "User";
	}
	/**
     * Submit Data
     */
	@RequestMapping(method={RequestMethod.POST})
	public String submit(Locale locale,@RequestParam String operation,@ModelAttribute("form")
	@Valid UserForm form,BindingResult bindingResult,Model model)
	{
		log.debug("UserCtl Submit Start");
		
	      if(OP_RESET.equalsIgnoreCase(form.getOperation()))
	        {
	     	   return "redirect:/ctl/UserCtl";
	        }
	      if(OP_CANCEL.equalsIgnoreCase(form.getOperation()))
	        {
	     	   return "redirect:/ctl/UserCtl/search";
	        }
	      
		if(bindingResult.hasErrors())
		{
			return "User";
		}
		try
		{
		if(OP_SAVE.equalsIgnoreCase(operation)|| OP_UPDATE.equalsIgnoreCase(operation))
		{
			UserDTO dto=(UserDTO)form.getDto();
			
			if(dto.getId()>0)
			{
				userService.update(dto);
			}else
			{
				long id=userService.add(dto);
				/*form.setId(id);*/
			}
			
			 
             
		}else if (OP_DELETE.equals(operation)) {

            userService.delete(form.getId());
            String msg = messageSource.getMessage("message.success", null,
                    locale);
            model.addAttribute("success", msg);
            return "redirect:/ctl/User/search";
        }
		}catch(Exception e)
		{
			log.error("Critical Issue", e);
			System.out.println("555555"+e.getMessage());
			 model.addAttribute("error", "" + e.getMessage());
			e.printStackTrace();
		}
		log.debug("UserCtl Submit End");
		return "User";
	}
	
	
	  /**
     * Displays User List
     * 
     * @param form
     * @param model
     * @return
     */
    @RequestMapping(value = "/search", method = RequestMethod.GET)
    public String searchList(@ModelAttribute("form") UserForm form, Model model) {
    	
    	log.debug("UserCtl get search Start");
        model.addAttribute("list",
                userService.search(null, form.getPageNo(), form.getPageSize()));
        log.debug("UserCtl get search End");
        return "UserList";
    }
    
    /**
     * Submits User List data.
     * 
     * @param locale
     * @param form
     * @param operation
     * @param model
     * @return
     */
    @RequestMapping(value = "/search", method = RequestMethod.POST)
    public String searchList(Locale locale,@ModelAttribute("form") UserForm form,
            @RequestParam(required = false) String operation, Model model) {
    	log.debug("UserCtl post search Start");
    	
    	 // Calculate next page number
        int pageNo = form.getPageNo();

        if (OP_NEXT.equals(operation)) {
            pageNo++;
        } else if (OP_PREVIOUS.equals(operation)) {
            pageNo--;
        }

        pageNo = (pageNo < 1) ? 1 : pageNo;

        form.setPageNo(pageNo);
        if(OP_RESET.equalsIgnoreCase(form.getOperation()))
        {
     	   return "redirect:/ctl/UserCtl/search";
        }else
             if(OP_NEW.equalsIgnoreCase(form.getOperation()))
        {
     	   return "redirect:/ctl/UserCtl";
        }else
              if (OP_DELETE.equalsIgnoreCase(operation)) {
            
                   if(form.getChk_1() != null)
                 {
                       for (long id : form.getChk_1()) {
            try {
					userService.delete(id);
				} catch (RecordNotFoundException e) 
                  {
					log.error("Critical Issue", e);
					e.printStackTrace();
				  }
            }

            String msg = messageSource.getMessage("message.success", null,
                    locale);
            model.addAttribute("success", msg);

        }else
        {
        	
             model.addAttribute("error", "Select Atleast One Record");	
        }
              }
        // Get search attributes
        UserDTO dto = (UserDTO) form.getDto();

        if(OP_DELETE.equalsIgnoreCase(operation))
        {
        	dto=null;
        }
         
        List list=userService.search(dto, pageNo, form.getPageSize());
        model.addAttribute("list",list);

  		if(list.size()==0 && !OP_DELETE.equalsIgnoreCase(operation)){
  			model.addAttribute("error","No Record Found ");
  		}
                  
    	 log.debug("UserCtl post search End");
    	 return "UserList";
    }

    /**
     * Display My profile
     *  
     * @param session
     * @param form
     * @param model
     * @return
     */
    @RequestMapping(value = "/profile", method = RequestMethod.GET)
    public String displayprofile(HttpSession session,@ModelAttribute("form") MyProfileForm form,Model model)
    {
    	log.debug("UserCtl displayProfile Start");
    	
    	UserDTO dto=(UserDTO)session.getAttribute("user");
    	form.populate(dto);
  
    	log.debug("UserCtl displayProfile End");
    	return "MyProfile";
    }
    
    /**
     * Submits MyProfile
     * 
     * @param locale
     * @param form
     * @param bindingResult
     * @param model
     * @return
     */
    @RequestMapping(value = "/profile", method = RequestMethod.POST)
    public String submitprofile(Locale locale,@ModelAttribute("form") 
    @Valid MyProfileForm form,BindingResult bindingResult,Model model)
    {
    	log.debug("UserCtl submitProfile Start");
    	
    	if(bindingResult.hasErrors())
    	{
    		return "MyProfile";
    	}
    	if(OP_SAVE.equalsIgnoreCase(form.getOperation()))
    	{
    	UserDTO dto;
		try {
			dto = userService.findByPK(form.getId());
			dto.setFirstName(form.getFirstName());
			dto.setLastName(form.getLastName());
			dto.setDob(Util.getDate(form.getDob()));
		    dto.setMobileNo(form.getMobileNo());
		    dto.setGender(form.getGender());
		    
		    userService.update(dto);
		    String msg = messageSource.getMessage("message.success", null, locale);
		    model.addAttribute("success", msg);

		      
		} catch (Exception e) {
			
			e.printStackTrace();
		}
    	}else if(OP_CHANGE_MY_PASSWORD.equalsIgnoreCase(form.getOperation()))
    	{
    		return "redirect:/ctl/UserCtl/changepassword";
    	}
    	
    	log.debug("UserCtl submitProfile Start");
    	 return "MyProfile";
    }
    
    /**
     * Displays Change Password view.
     * 
     * @param form
     * @param model
     * @return
     */
    @RequestMapping(value = "/changepassword", method = RequestMethod.GET)
    public String displayChangePassword(
            @ModelAttribute("form") ChangePasswordForm form, Model model) {
        log.debug("displayChangePassword start");
        return "ChangePassword";
    }
    
    /**
     * Submits Change Password data.
     * 
     * @param session
     * @param form
     * @param model
     * @return
     */
    @RequestMapping(value = "/changepassword", method = RequestMethod.POST)
    public String submitChangePassword(Locale locale, HttpSession session,
            @ModelAttribute("form") @Valid ChangePasswordForm form,
            BindingResult bindingResult, Model model) {

    	 if(OP_RESET.equalsIgnoreCase(form.getOperation()))
         {
      	   return "redirect:/ctl/UserCtl/changepassword";
         }
    	 
        if (bindingResult.hasErrors()) {
            return "ChangePassword";
        }
      
        System.out.println("form*** "+form.getId());
     // New password and confirm password must be same
        if(form.getNewPassword().equals(form.getConfirmPassword()))
        {
        	try 
        	{
			       UserDTO dto=(UserDTO) session.getAttribute("user");	
				   dto=userService.findByPK(dto.getId());
				// Old password must be valid
				if(dto.getPassword().equals(form.getOldPassword()))
				{
					// Change Password
					//dto.setPassword(form.getNewPassword());
					userService.changePassword(dto.getId(),dto. getPassword(), form.getNewPassword());
					
					String msg=messageSource.getMessage("message.success", null, locale);
					model.addAttribute("success",msg);
				}else {
	                model.addAttribute("error", "Old Password is not valid.");
	            }
				
				
			} catch (Exception e) 
        	{
				e.printStackTrace();
			}
        }else {
            model.addAttribute("error",
                    "New Password and Confirm Password does not match");
        }
        
        return "ChangePassword";
    }
    

}
