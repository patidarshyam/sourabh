package com.sunilos.proj0.ctl;

import java.util.List;
import java.util.Locale;

import javax.validation.Valid;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.sunilos.proj0.dto.RoleDTO;
import com.sunilos.proj0.dto.SubjectDTO;
import com.sunilos.proj0.exception.RecordNotFoundException;
import com.sunilos.proj0.form.SubjectForm;
import com.sunilos.proj0.service.CourseServiceInt;
import com.sunilos.proj0.service.SubjectServiceInt;

/**
 * Contains navigation logics for Subject and Subject List usecases.
 * 
 * @author OB Server
 * @version 1.0
 * @Copyright (c) OB Server
 */

@Controller
@RequestMapping(value="/ctl/Subject")
public class SubjectCtl extends BaseCtl{
	
	/**
     * Logger object
     */
	private static Logger log=Logger.getLogger(SubjectCtl.class);
	
	@Autowired
	SubjectServiceInt service;
	
	@Autowired
	CourseServiceInt courseService;
	
	@Autowired
	MessageSource messageSource;
	
	/**
     * Preload Course List
     */
	@Override
	public void preload(Model model) {
		
		log.debug("SubjectCtl preload start");
		
		System.out.println("Preload method of SubjectCtl");
		List list=courseService.search(null);
		model.addAttribute("courseList", list);
		
		List list1=service.search(null, 0, 0);
		model.addAttribute("subjectList", list1);
		log.debug("SubjectCtl preload End");
	}
	/**
	 * Subject Display View
	 * 
	 * @param id
	 * @param form
	 * @param model
	 * @return
	 */
	@RequestMapping(method=RequestMethod.GET)
	public String display(@RequestParam(required=false) Long id, @ModelAttribute("form") SubjectForm form,Model model)
	{
		log.debug("SubjectCtl display start");
		
		if(id!=null && id>0)
		{
			try 
			{
				SubjectDTO dto=service.findByPK(id);
				form.populate(dto);
				
			} catch (RecordNotFoundException e) {
				
			  log.error("Critical issue",e);
				e.printStackTrace();
				
			}
		}
		log.debug("SubjectCtl display End");
		return "Subject";
	}
	
	/**
	 * Submit Subject View
	 * 
	 * @param locale
	 * @param operation
	 * @param form
	 * @param bindingResult
	 * @param model
	 * @return
	 */
	@RequestMapping(method=RequestMethod.POST)
	public String submit(Locale locale,@RequestParam String operation,
		@ModelAttribute("form") @Valid SubjectForm form,BindingResult bindingResult,Model model	)
	{
		log.debug("SubjectCtl Submit start");
		
		if(OP_RESET.equalsIgnoreCase(operation))
		{
			return "redirect:/ctl/Subject";
		}
		  if(OP_CANCEL.equalsIgnoreCase(form.getOperation()))
	        {
	     	   return "redirect:/ctl/Subject/search";
	        }
		if(bindingResult.hasErrors())
		{
			System.out.println("Error"+form.getCourseId());
			System.out.println(bindingResult.getFieldErrors()+" ***");
			return "Subject";
		}
		
		try
		{
		if(OP_SAVE.equalsIgnoreCase(operation) || OP_UPDATE.equalsIgnoreCase(operation))
		{
			SubjectDTO dto=(SubjectDTO)form.getDto();
			System.out.println("OP get");
			if(dto.getId()>0)
			{
				System.out.println("In Update");
				service.update(dto);
				
			}else
			{
				System.out.println("In Add");
				long id=service.add(dto);
				/*form.setId(id);*/
				
			}
			String msg=messageSource.getMessage("message.success", null,locale);
			model.addAttribute("success", msg);
		}else if(OP_DELETE.equalsIgnoreCase(operation))
		{
			service.delete(form.getId());
			
			String msg = messageSource.getMessage("message.success", null,
                    locale);
            model.addAttribute("success", msg);

            return "redirect:/ctl/Subject/search";
		}
		}catch(Exception e)
		{
			log.error("Critical Issue", e);
			e.printStackTrace();
			model.addAttribute("error",""+e.getMessage());
		}
		
		log.debug("SubjectCtl Submit End");
		return "Subject";
	}

	 /**
     * Displays Subject List view.
     * 
     * @param form
     * @param model
     * @return
     */
    @RequestMapping(value = "/search", method = RequestMethod.GET)
    public String searchList(@ModelAttribute("form") SubjectForm form, Model model) {
        model.addAttribute("list",
                service.search(null, form.getPageNo(), form.getPageSize()));
        return "SubjectList";
    }

    /**
     * Submits Subject List data.
     * 
     * @param locale
     * @param form
     * @param operation
     * @param model
     * @return
     */
    @RequestMapping(value = "/search", method = {RequestMethod.POST })
    public String searchList(Locale locale,
            @ModelAttribute("form") SubjectForm form,
            @RequestParam(required = false) String operation, Model model) {

        log.debug("in searchList method");

     
       
        // Calculate next page number
        int pageNo = form.getPageNo();

        if (OP_NEXT.equals(operation)) {
            pageNo++;
        } else if (OP_PREVIOUS.equals(operation)) {
            pageNo--;
        }

        pageNo = (pageNo < 1) ? 1 : pageNo;

        form.setPageNo(pageNo);
        if(OP_RESET.equalsIgnoreCase(form.getOperation()))
        {
     	   return "redirect:/ctl/Subject/search";
        }else
             if(OP_NEW.equalsIgnoreCase(form.getOperation()))
        {
     	   return "redirect:/ctl/Subject";
        }else
              if (OP_DELETE.equalsIgnoreCase(operation)) {
            
            	   if(form.getChk_1() != null)
            	  {
                       for (long id : form.getChk_1()) {
            try {
					service.delete(id);
				} catch (RecordNotFoundException e) 
                  {
					log.error("Critical Issue", e);
					e.printStackTrace();
				  }
            }

            String msg = messageSource.getMessage("message.success", null,
                    locale);
            model.addAttribute("success", msg);

        }else
        {
        	
             model.addAttribute("error", "Select Atleast One Record");	
        }
              }
        // Get search attributes
        SubjectDTO dto = (SubjectDTO) form.getDto();

        if(OP_DELETE.equalsIgnoreCase(operation))
        {
        	dto=null;
        }
         
        List list=service.search(dto, pageNo, form.getPageSize());
        model.addAttribute("list",list);

  		if(list.size()==0 && !OP_DELETE.equalsIgnoreCase(operation)){
  			System.out.println("List size 000");
  			model.addAttribute("error","No Record Found ");
  		}
        return "SubjectList";
    }

}
