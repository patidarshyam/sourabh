package com.sunilos.proj0.dao;

import java.util.List;

import org.springframework.dao.DataAccessException;

import com.sunilos.proj0.dto.StudentDTO;

/**
 * 
 * Student DAO interface.
 * 
 * @author OB Server
 * @version 1.0
 * @Copyright (c) OB Server
 */

public interface StudentDAOInt {

/**
 * Add Student
 * 
 * @param dto
 * @return
 * @throws DataAccessException
 */
public long add(StudentDTO dto) throws DataAccessException;

/**
 * Update Student
 * 
 * @param dto
 * @throws DataAccessException
 */
public void update(StudentDTO dto) throws DataAccessException;

/**
 * Delete Student
 * 
 * @param dto
 * @throws DataAccessException
 */
public void delete(StudentDTO dto) throws DataAccessException;

/**
 * find Student By Pk
 * 
 * @param pk
 * @return
 * @throws DataAccessException
 */
public StudentDTO findByPK(long pk) throws DataAccessException;

/**
 * find Student By Login 
 * 
 * @param login
 * @return
 * @throws DataAccessException
 */
public StudentDTO findByLogin(String login)throws DataAccessException;

/**
 * Search Student with pagination
 * 
 * @param dto
 * @param pageNo
 * @param pageSize
 * @return List of User
 * @throws DataAccessException
 */
public List<StudentDTO> search(StudentDTO dto,int pageNo,int pageSize) throws DataAccessException;

/**
 * Search Student
 * 
 * @param dto
 * @return
 * @throws DataAccessException
 */
public List<StudentDTO> search(StudentDTO dto)throws DataAccessException;

}

