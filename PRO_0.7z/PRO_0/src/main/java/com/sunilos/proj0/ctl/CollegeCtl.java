package com.sunilos.proj0.ctl;

import java.util.List;
import java.util.Locale;

import javax.validation.Valid;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.sunilos.proj0.dto.CollegeDTO;
import com.sunilos.proj0.dto.RoleDTO;
import com.sunilos.proj0.exception.RecordNotFoundException;
import com.sunilos.proj0.form.CollegeForm;
import com.sunilos.proj0.service.CollegeServiceInt;

/**
 * Contains navigation logics for College and College List usecases.
 * 
 * @author OB Server
 * @version 1.0
 * @Copyright (c) OB Server
 */
@Controller
@RequestMapping(value="/ctl/College")

  public class CollegeCtl extends BaseCtl
{
	/**
     * Logger object
     */
	private static Logger log=Logger.getLogger(CollegeCtl.class);
	
	/**
     * College Service
     */
	@Autowired
	private CollegeServiceInt service;
	
	/**
     * i18n Message source
     */
	@Autowired
	private MessageSource messageSource;
	
	 
    /**
     * Preload College List
     */
	@Override
	public void preload(Model model) {
		
		log.debug("CollegeCtl preload start");
		
		System.out.println("Preload method of CollegeCtl");
		
		List list=service.search(null, 0, 0);
		model.addAttribute("collegeList", list);
		log.debug("CollegeCtl preload End");
	}
	
	
	/**
	 * Display Method 
	 * 
	 * @param locale
	 * @param id
	 * @param form
	 * @param model
	 * @return
	 */
	@RequestMapping(method=RequestMethod.GET)
	public String display(Locale locale,@RequestParam(required=false)Long id,@ModelAttribute("form") CollegeForm form,Model model)
	{
		log.debug("CollegeCtl display start");
		
		if(id!=null && id>0)
		{
			CollegeDTO dto=service.findById(id);
			form.populate(dto);
		}
		log.debug("CollegeCtl display End");
		return "College";
	}
	
	/**
	 * @param locale
	 * @param operation
	 * @param forms
	 * @param form
	 * @param result
	 * @param model
	 * @return
	 */
	@RequestMapping(method=RequestMethod.POST)
	public String submit(Locale locale,@RequestParam String operation,@ModelAttribute("form")
			@Valid CollegeForm form,BindingResult result,Model model)
	{
		log.debug("CollegeCtl submit Start");
		
		 if(OP_RESET.equalsIgnoreCase(form.getOperation()))
	        {
	     	   return "redirect:/ctl/College";
	        }
		 if(OP_CANCEL.equalsIgnoreCase(form.getOperation()))
	        {
	     	   return "redirect:/ctl/College/search";
	        }
		 
		if(result.hasErrors())
		{
			return "College";
		}
		
		CollegeDTO dto=(CollegeDTO)form.getDto();
		
		try
		{
		if(OP_SAVE.equalsIgnoreCase(operation)||OP_UPDATE.equalsIgnoreCase(operation))
		{
			
				
			if(dto.getId()>0)
			{
				service.update(dto);
			}else
			{
				service.add(dto);
			}
			String msg=messageSource.getMessage("message.success",null,locale);
			model.addAttribute("success", msg);
			
		}else if(OP_DELETE.equalsIgnoreCase(operation))
		{
			service.delete(form.getId());
			
		     String msg = messageSource.getMessage("message.success", null,
                     locale);
             model.addAttribute("success", msg);

             return "redirect:/ctl/College/search";
		}
		
		}catch(Exception e)
		{
			 log.error(e);
	         model.addAttribute("error", " " + e.getMessage());	
		}
		log.debug("CollegeCtl submit End");
		return "College";
	}
	
	@RequestMapping(value="/search",method={RequestMethod.GET})
	public String searchList(@ModelAttribute("form") CollegeForm form,Model model)
	{
		log.debug("CollegeCtl searchList Start for Display");
		
		List list=service.search(null, form.getPageNo(),form.getPageSize());
		model.addAttribute("list", list);
		
		log.debug("CollegeCtl searchList End");
		return "CollegeList";
	}
	
	/**
	 * Contains submit logics of College List View
	 * 
	 * @param locale
	 * @param form
	 * @param operation
	 * @param model
	 * @return
	 */
	@RequestMapping(value="/search",method={RequestMethod.POST})
	public String searchList(Locale locale,@ModelAttribute("form") CollegeForm form,
			@RequestParam(required=false) String operation,Model model)
	{
		log.debug("CollegeCtl searchList Start for Submit");
		
		 // Calculate next page number
        int pageNo = form.getPageNo();

        if (OP_NEXT.equals(operation)) {
            pageNo++;
        } else if (OP_PREVIOUS.equals(operation)) {
            pageNo--;
        }

        pageNo = (pageNo < 1) ? 1 : pageNo;

        form.setPageNo(pageNo);
        
        if(OP_RESET.equalsIgnoreCase(form.getOperation()))
        {
     	   return "redirect:/ctl/College/search";
        }else
             if(OP_NEW.equalsIgnoreCase(form.getOperation()))
        {
     	   return "redirect:/ctl/College";
        }else
              if (OP_DELETE.equalsIgnoreCase(operation)) {
            
            	   if(form.getChk_1() != null)
            	  {
                       for (long id : form.getChk_1()) {
            try {
					service.delete(id);
				} catch (RecordNotFoundException e) 
                  {
					log.error("Critical Issue", e);
					e.printStackTrace();
				  }
            }

            String msg = messageSource.getMessage("message.success", null,
                    locale);
            model.addAttribute("success", msg);

        }else
        {
        	
             model.addAttribute("error", "Select Atleast One Record");	
        }
              }
        // Get search attributes
        CollegeDTO dto = (CollegeDTO) form.getDto();

        if(OP_DELETE.equalsIgnoreCase(operation))
        {
        	dto=null;
        }
         
        List list=service.search(dto, pageNo, form.getPageSize());
        model.addAttribute("list",list);

  		if(list.size()==0 && !OP_DELETE.equalsIgnoreCase(operation)){
  			model.addAttribute("error","No Record Found ");
  		}
          
		log.debug("CollegeCtl searchList End");
		return "CollegeList";
	}
}
