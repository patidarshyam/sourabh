package com.sunilos.proj0.dao;

import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.sunilos.proj0.dto.SubjectDTO;
/**
 * Hibernate implementation of Subject DAO.
 * 
 * @author OB Server
 * @version 1.0
 * @Copyright (c) OB Server
 * 
 */
@Repository("subjectDAO")
public class SubjectDAOHibImpl implements SubjectDAOInt{

	@Autowired
	SessionFactory sessionFactory=null;
	
	public static Logger log=Logger.getLogger(SubjectDAOHibImpl.class);
	
	/**
	 * Add Subject
	 *
	 */
	public long add(SubjectDTO dto) {

		log.debug("SubjectDAOHibImpl add starts");
		long pk=(Long)sessionFactory.getCurrentSession().save(dto);
		log.debug("SubjectDAOHibImpl add end");
		return pk;
	}
	/**
	 * Update Subject
	 *
	 */
	public void update(SubjectDTO dto) {

		log.debug("SubjectDAOHibImpl Update starts");
		sessionFactory.getCurrentSession().merge(dto);
		log.debug("SubjectDAOHibImpl Update End");
		
	}
	/**
	 *Delete Subject
	 *
	 */
	public void delete(SubjectDTO dto) {

		log.debug("SubjectDAOHibImpl Delete starts");
		sessionFactory.getCurrentSession().delete(dto);
		log.debug("SubjectDAOHibImpl Delete End");
		
	}
	/**
	 * find by Pk
	 *
	 */
	public SubjectDTO findByPK(long pk) {
    
		log.debug("SubjectDAOHibImpl findByPK starts");
		
		SubjectDTO dto=null;
		dto=(SubjectDTO)sessionFactory.openSession().get(SubjectDTO.class, pk);
		
		log.debug("SubjectDAOHibImpl findByPK End");
		return dto;
	}
	/**
	 * find Subject by Name
	 *
	 */
	public SubjectDTO findByName(String name) {

       log.debug("SubjectDAOHibImpl findByName starts");
		
		SubjectDTO dto=null;
		Criteria criteria=sessionFactory.getCurrentSession().createCriteria(SubjectDTO.class);
		List list=criteria.add(Restrictions.like("subjectName", name)).list();
		
		if(list.size()==1)
		{
			dto=(SubjectDTO)list.get(0);
		}
		log.debug("SubjectDAOHibImpl findByName End");
		return dto;
	}
	  /**
     * Search Subject
     * 
     * @return list : List of Subject
     * @param dto
     *            : Search Parameters
     */
	public List<SubjectDTO> search(SubjectDTO dto, int pageNo, int pageSize) {

        log.debug("SubjectDAOHibImpl Search starts");
		
		Criteria criteria=sessionFactory.getCurrentSession().createCriteria(SubjectDTO.class);
		
		/*if(dto.getId()>0)
		{
			criteria.add(Restrictions.eq("id", dto.getId()));
		}*/
		if(dto!=null)
		{
		
		if(dto.getSubjectName()!=null && dto.getSubjectName().length()>0)
		{
			criteria.add(Restrictions.like("subjectName", dto.getSubjectName()+ "%"));
		}System.out.println("courseId hai       ////  "+dto.getCourseId());
		if (dto.getCourseId() > 0) {
				System.out.println("courseId hai       ////  "+dto.getCourseId());
				criteria.add(Restrictions.eq("courseId", dto.getCourseId()));
			}
		if(dto.getCourseName()!=null && dto.getCourseName().length()>0)
		{
		   criteria.add(Restrictions.like("courseName", dto.getCourseName()+ "%"));
		}
		if(dto.getDescription()!=null && dto.getDescription().length()>0)
		{
		   criteria.add(Restrictions.like("description", dto.getDescription()+ "%"));
		}
		
		System.out.println("courseId hai       ////  "+dto.getCourseId());
		
		}
		if(pageSize>0)
		{
			criteria.setFirstResult((pageNo-1)*pageSize);
			criteria.setMaxResults(pageSize);
		}
		List<SubjectDTO> list=criteria.list();
        Iterator it=list.iterator();
        while (it.hasNext()) {
			SubjectDTO object = (SubjectDTO) it.next();
			System.out.println(list.size());
		}
		log.debug("SubjectDAOHibImpl Search End");
		return list;

	}
	  /**
     * Search Subject
     * 
     * @return list : List of Subject
     * @param dto
     *            : Search Parameters
     */
	public List<SubjectDTO> search(SubjectDTO dto) {
		return search(dto, 0, 0);
	}
	

}
