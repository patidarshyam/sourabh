package com.sunilos.proj0.dao;

import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.sunilos.proj0.dto.CollegeDTO;

/**
 * Hibernate implementation of College DAO.
 * 
 * @author OB Server
 * @version 1.0
 * @Copyright (c) OB Server
 * 
 */

@Repository
public class CollegeDAOHibImpl implements CollegeDAOInt {

	@Autowired
	SessionFactory sessionFactory=null;
	
	public static Logger log=Logger.getLogger(CollegeDAOHibImpl.class);
	/**
	 * Add College
	 *
	 */
	public long add(CollegeDTO dto) {
		
		log.debug("CollegeDAOHibImpl add starts");
		long pk=(Long)sessionFactory.getCurrentSession().save(dto);
		log.debug("CollegeDAOHibImpl add end");
		return pk;
	}
	/**
	 * Update College
	 *
	 */
	public void update(CollegeDTO dto) {

		log.debug("CollegeDAOHibImpl Update starts");
		sessionFactory.getCurrentSession().merge(dto);
		log.debug("CollegeDAOHibImpl Update End");
		
	}
	/**
	 *Delete College 
	 *
	 */
	public void delete(CollegeDTO dto) {

		log.debug("CollegeDAOHibImpl Delete starts");
		sessionFactory.getCurrentSession().delete(dto);
		log.debug("CollegeDAOHibImpl Delete End");
		
	}
	/**
	 * find by Pk
	 *
	 */
	public CollegeDTO findByPK(long pk) {
        log.debug("CollegeDAOHibImpl findByPK starts");
		
		CollegeDTO dto=null;
		dto=(CollegeDTO)sessionFactory.openSession().get(CollegeDTO.class, pk);
		
		log.debug("CollegeDAOHibImpl findByPK End");
		return dto;
	}
	/**
	 * find College by Name
	 *
	 */
	public CollegeDTO findByName(String name) {
        
		log.debug("CollegeDAOHibImpl findByName starts");
		
		CollegeDTO dto=null;
		Criteria criteria=sessionFactory.getCurrentSession().createCriteria(CollegeDTO.class);
		criteria.add(Restrictions.like("name", name));
		List list=criteria.list();
		if(list.size()>0)
		{
			dto=(CollegeDTO)list.get(0);
		}
		log.debug("CollegeDAOHibImpl findByName End");
		return dto;
	}

	 /**
    * Search College with pagination
    * 
    * @return list : List of College
    * @param dto
    *            : Search Parameters
    * @param pageNo
    *            : Current Page No.
    * @param pageSize
    *            : Size of Page
    * 
    */
	public List<CollegeDTO> search(CollegeDTO dto, int pageNo, int pageSize) {


        log.debug("CollegeDAOHibImpl Search starts");
		
		Criteria criteria=sessionFactory.getCurrentSession().createCriteria(CollegeDTO.class);
		
		/*if(dto.getId()>0)
		{
			criteria.add(Restrictions.eq("id", dto.getId()));
		}*/
		if(dto!=null)
		{
		/*if(dto.getName()!=null && dto.getName().length()>0)
		{
			criteria.add(Restrictions.like("name", dto.getName()+ "%"));
		}
		if(dto.getState()!=null && dto.getState().length()>0)
		{
		   criteria.add(Restrictions.like("state", dto.getState()+ "%"));
		}
	*/	 if (dto.getName() != null && dto.getName().length() > 0) {
             criteria.add(Restrictions.like("name", dto.getName() + "%"));
         }
         if (dto.getAddress() != null && dto.getAddress().length() > 0) {
             criteria.add(Restrictions.like("address", dto.getAddress()
                     + "%"));
         }
         if (dto.getState() != null && dto.getState().length() > 0) {
             criteria.add(Restrictions.like("state", dto.getState() + "%"));
         }
         if (dto.getCity() != null && dto.getCity().length() > 0) {
             criteria.add(Restrictions.like("city", dto.getCity() + "%"));
         }

		
		}
		
		if(pageSize>0)
		{
			criteria.setFirstResult((pageNo-1)*pageSize);
			criteria.setMaxResults(pageSize);
		}
		List<CollegeDTO> list=criteria.list();
		log.debug("CollegeDAOHibImpl Search End");
		return list;

	}

	  /**
   * Search College
   * 
   * @return list : List of College
   * @param dto
   *            : Search Parameters
   */
	public List<CollegeDTO> search(CollegeDTO dto) {
		return search(dto, 0, 0);
	}

}
