package com.sunilos.proj0.dao;

import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import com.sunilos.proj0.dto.MarksheetDTO;


/**
 * Hibernate implementation of College DAO.
 * 
 * @author SunilOS
 * @version 1.0
 * @Copyright (c) SunilOS
 * 
 */
@Repository("marksheetDAO")
public class MarksheetDAOHibImpl implements MarksheetDAOInt {

    @Autowired
    private SessionFactory sessionFactory = null;
    public static Logger log=Logger.getLogger(MarksheetDAOHibImpl.class);
	

    /**
	 * Add marksheet
	 *
	 */
    // add method
    public long add(MarksheetDTO dto) {
    	log.debug("MarksheetDAOHibImpl add starts");
        Long pk= (Long) sessionFactory.getCurrentSession().save(dto);
        log.debug("MarksheetDAOHibImpl add End");
        return pk;
    }

    /**
	 * update marksheet
	 *
	 */
    // update method
    public void update(MarksheetDTO dto) {
    	log.debug("MarksheetDAOHibImpl update starts");
        sessionFactory.getCurrentSession().merge(dto);
        log.debug("MarksheetDAOHibImpl update End");
       
    }
    /**
	 * delete marksheet
	 *
	 */
    // delete method
    public void delete(MarksheetDTO dto) {
    	log.debug("MarksheetDAOHibImpl delete starts");
          sessionFactory.getCurrentSession().delete(dto);
          log.debug("MarksheetDAOHibImpl delete End");
    }

    /**
     * Search Marksheet
     * 
     * @return list : List of Marksheet
     * @param dto
     *            : Search Parameters
     */
    public List search(MarksheetDTO dto) {
        return search(dto, 0, 0);
    }

    /**
     * Search Users
     * 
     * @return list : List of Users
     * @param dto
     *            : Search Parameters
     */
    public List search(MarksheetDTO dto, int pageNo, int pageSize) {
        System.out.println("DAO search Started");
        log.debug("MarksheetDAOHibImpl search starts");
        Criteria c = sessionFactory.getCurrentSession().createCriteria(
                MarksheetDTO.class);

        if (dto != null) {

            if (dto.getStudentId() != null && dto.getStudentId() > 0) {
                c.add(Restrictions.eq("studentId", dto.getStudentId()));
            }
            if (dto.getName()!= null && dto.getName().length()>0) {
                c.add(Restrictions.eq("name", dto.getName()));
            }
           /* if (dto.getRollNo()!= null && dto.getRollNo().length()>0) {
                c.add(Restrictions.like("rollNo", dto.getRollNo()));
            }*/
            if (dto.getRollNo()!= null && dto.getRollNo().length()>0) {
                c.add(Restrictions.like("rollNo", dto.getRollNo()
                        + "%"));
            }
        }
            if (pageSize > 0) {
                c.setFirstResult((pageNo - 1) * pageSize);
                c.setMaxResults(pageSize);
            }
        
        List <MarksheetDTO>list=c.list();
        log.debug("MarksheetDAOHibImpl search End");
        return list;
    }

    /**
	 * Find By pk
	 *
	 */
    public MarksheetDTO findByPK(long pk) {
     	log.debug("MarksheetDAOHibImpl findByPK starts");
        MarksheetDTO dto = (MarksheetDTO) sessionFactory.getCurrentSession().get(MarksheetDTO.class, pk);
     	log.debug("MarksheetDAOHibImpl findByPK End");
        return dto;
    }

    /**
	 * Find By RollNo
	 *
	 */
    public MarksheetDTO findByRollNo(String rollNo) {
    	log.debug("MarksheetDAOHibImpl findByRollNo Starts");
    	
        Criteria criteria = sessionFactory.getCurrentSession().createCriteria(MarksheetDTO.class);
        criteria.add(Restrictions.eq("rollNo", rollNo));
        List<MarksheetDTO> list = criteria.list();

        MarksheetDTO dto = null;

        if (list.size() == 1) {
            dto = (MarksheetDTO) list.get(0);
        }
        log.debug("MarksheetDAOHibImpl findByRollNo End");
        return dto;
    }

    /**
	 *GetMerit List
	 *
	 */
    public List getMeritList(int pageNo, int pageSize) {
    	log.debug("MarksheetDAOHibImpl GetMeritList Start");
    	System.out.println("MarksheetDAOHibImpl GetMeritList Start");
    	 List list = null;
    	 Session session = sessionFactory.getCurrentSession();
    	StringBuffer hql=new StringBuffer("from MarksheetDTO where physics>35 and chemistry>35 and maths>35  order by (physics + chemistry + maths) desc");
		
       
        Query q = session.createQuery(hql.toString());
        if(pageSize>0){
			pageNo=(pageNo-1)*pageSize;
			q.setFirstResult(pageNo);
			q.setMaxResults(pageSize);
			}
        list = q.list();
        System.out.println("quiry++++"+q);
        System.out.println("MarksheetDAOHibImpl GetMeritList end");
    	log.debug("MarksheetDAOHibImpl GetMeritList End");
        return list;
        
      }
}
