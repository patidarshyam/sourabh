package com.sunilos.proj0.dao;

import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.sunilos.proj0.dto.TimeTableDTO;
/**
 * Hibernate implementation of TimeTable DAO.
 * 
 * @author OB Server
 * @version 1.0
 * @Copyright (c) OB Server
 * 
 */

@Repository("timetableDAO")
public class TimeTableDAOHibImpl implements TimeTableDAOInt{


	@Autowired
	SessionFactory sessionFactory=null;
	
	public static Logger log=Logger.getLogger(TimeTableDAOHibImpl.class);
	
	/**
	 * Add TimeTable
	 *
	 */
	public long add(TimeTableDTO dto) {

		log.debug("TimeTableDAOHibImpl add starts");
		long pk=(Long)sessionFactory.getCurrentSession().save(dto);
		log.debug("TimeTableDAOHibImpl add end");
		return pk;
		
	}
	/**
	 * Update TimeTable
	 *
	 */
	public void update(TimeTableDTO dto) {

		   log.debug("TimeTableDAOHibImpl Update Started");
	       sessionFactory.getCurrentSession().merge(dto);
	       log.debug("TimeTableDAOHibImpl Update Ended");
		
		
	}
	/**
	 *Delete TimeTable
	 *
	 */
	public void delete(TimeTableDTO dto) {

		log.debug("TimeTableDAOHibImpl Delete starts");
		sessionFactory.getCurrentSession().delete(dto);
		log.debug("TimeTableDAOHibImpl Delete End");
		
	}
	/**
	 * find by Pk
	 *
	 */
	public TimeTableDTO findByPK(long pk) {
       
		log.debug("TimeTableDAOHibImpl findByPK starts");
		
		TimeTableDTO dto=null;
		dto=(TimeTableDTO)sessionFactory.openSession().get(TimeTableDTO.class, pk);
		
		log.debug("TimeTableDAOHibImpl findByPK End");
		return dto;
	}
	/**
	 * find TimeTable by CourseSubject
	 *
	 */
	public TimeTableDTO findByCourseNameSubjectName(String courseName,String subjectName) {

        log.debug("TimeTableDAOHibImpl findByCourseNameSubjectName starts");
		
		TimeTableDTO dto=null;
		Criteria criteria=sessionFactory.getCurrentSession().createCriteria(TimeTableDTO.class);
	    criteria.add(Restrictions.like("courseName", courseName));
	    criteria.add(Restrictions.like("subjectName", subjectName));
		
	    List list=criteria.list();
		if(list.size()==1)
		{
			dto=(TimeTableDTO)list.get(0);
		}
		log.debug("TimeTableDAOHibImpl findByCourseNameSubjectName End");
		return dto;
	}
	/**
	 * find TimeTable by CourseExamDate
	 *
	 */
	public TimeTableDTO findByCourseNameExamDate(String courseName,Date examDate) {

       log.debug("TimeTableDAOHibImpl findByCourseNameExamDate starts");
		
		TimeTableDTO dto=null;
		Criteria criteria=sessionFactory.getCurrentSession().createCriteria(TimeTableDTO.class);
	    criteria.add(Restrictions.like("courseName", courseName));
	    criteria.add(Restrictions.like("examDate", examDate));
		
	    List list=criteria.list();
		if(list.size()==1)
		{
			dto=(TimeTableDTO)list.get(0);
		}
		log.debug("TimeTableDAOHibImpl findByExamDate End");
		return dto;
	}
	  /**
     * Search TimeTable
     * 
     * @return list : List of TimeTable
     * @param dto
     *            : Search Parameters
     */
	public List<TimeTableDTO> search(TimeTableDTO dto, int pageNo, int pageSize) {

        log.debug("TimeTableDAOHibImpl Search starts");
		
		Criteria criteria=sessionFactory.getCurrentSession().createCriteria(TimeTableDTO.class);
		
		/*if(dto.getId()>0)
		{
			criteria.add(Restrictions.eq("id", dto.getId()));
		}*/
		if(dto!=null)
		{
		if(dto.getCourseId()>0)
		{
			criteria.add(Restrictions.eq("courseId", dto.getCourseId()));
		}
		if(dto.getSubjectId()>0)
		{
			criteria.add(Restrictions.eq("subjectId", dto.getSubjectId()));
		}
		if(dto.getExamDate()!=null && dto.getExamDate().toString().length()>0)
		{
			criteria.add(Restrictions.like("examDate", dto.getExamDate()));
		}
		if(dto.getSubjectName()!=null && dto.getSubjectName().length()>0)
		{
			criteria.add(Restrictions.like("subjectName", dto.getSubjectName()));
		}
		}
		if(pageSize>0)
		{
			criteria.setFirstResult((pageNo-1)*pageSize);
			criteria.setMaxResults(pageSize);
		}
		List<TimeTableDTO> list=criteria.list();
		log.debug("TimeTableDAOHibImpl Search End");
		return list;

	}
	  /**
     * Search TimeTable
     * 
     * @return list : List of Timetable
     * @param dto
     *            : Search Parameters
     */
	public List<TimeTableDTO> search(TimeTableDTO dto) {
		
		return search(dto, 0, 0);
		
	}

}
