package com.sunilos.proj0.ctl;

import java.util.List;
import java.util.Locale;

import javax.validation.Valid;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.sunilos.proj0.dto.RoleDTO;
import com.sunilos.proj0.exception.RecordNotFoundException;
import com.sunilos.proj0.form.RoleForm;
import com.sunilos.proj0.service.RoleServiceInt;

/**
 * Contains navigation logics for Marksheet and Marksheet  List usecases.
 * 
 * @author OB Server
 * @version 1.0
 * @Copyright (c) OB Server
 */
@Controller
@RequestMapping(value = "/ctl/Role")
public class RoleCtl extends BaseCtl {

    private static Logger log = Logger.getLogger(RoleCtl.class);

    @Autowired
    private RoleServiceInt service;

    /**
     * i18n Message source
     */
    @Autowired
    private MessageSource messageSource;
    
    /**
     * Preload Role List
     */
	@Override
	public void preload(Model model) {
		
		log.debug("UserCtl preload start");
		
		System.out.println("Preload method of RolelCtl");
		
		List list=service.search(null, 0, 0);
		model.addAttribute("roleList", list);
		log.debug("UserCtl preload End");
	}
	
	

    /**
     * Displays Role view.
     * 
     * @param id
     * @param form
     * @param model
     * @return
     */
    @RequestMapping(method = RequestMethod.GET)
    public String display(@RequestParam(required = false) Long id,
            @ModelAttribute("form") RoleForm form, Model model) {

        log.debug("RoleCtl doDisplay() Start");

        if (id != null && id > 0) {
            form.populate(service.findById(id));
        }
        return "Role";
    }

    /**
     * Submits Role data.
     * 
     * @param locale
     * @param operation
     * @param form
     * @param bindingResult
     * @param model
     * @return
     */
    @RequestMapping(method = RequestMethod.POST)
    public String submit(Locale locale,
            @RequestParam(required = false) String operation,
            @ModelAttribute("form") @Valid RoleForm form,
            BindingResult bindingResult, Model model) {

        log.debug("RoleCtl doSubmit() Start");

        if(OP_RESET.equalsIgnoreCase(form.getOperation()))
        {
     	   return "redirect:/ctl/Role";
        }
        if(OP_CANCEL.equalsIgnoreCase(form.getOperation()))
        {
     	   return "redirect:/ctl/Role/search";
        }
        
        if (bindingResult.hasErrors()) {
            return "Role";
        }
      

        try {
            if (OP_SAVE.equalsIgnoreCase(operation) || OP_UPDATE.equalsIgnoreCase(operation)) {

                RoleDTO dto = (RoleDTO) form.getDto();

                if (dto.getId() > 0) {
                    service.update(dto);
                } else {
                    long id = service.add(dto);
                   /* form.setId(id);*/
                }
                String msg = messageSource.getMessage("message.success", null,
                        locale);
                model.addAttribute("success", msg);

            } else if (OP_DELETE.equalsIgnoreCase(operation)) {
                service.delete(form.getId());
                String msg = messageSource.getMessage("message.success", null,
                        locale);
                model.addAttribute("success", msg);
                return "redirect:/ctl/Role/search";
            }

        } catch (Exception e) {
            model.addAttribute("error", " " + e.getMessage());
        }

        return "Role";
    }

    /**
     * Displays Role List view.
     * 
     * @param form
     * @param model
     * @return
     */
    @RequestMapping(value = "/search", method = RequestMethod.GET)
    public String searchList(@ModelAttribute("form") RoleForm form, Model model) {
        model.addAttribute("list",
                service.search(null, form.getPageNo(), form.getPageSize()));
        return "RoleList";
    }

    /**
     * Submits Role List data.
     * 
     * @param locale
     * @param form
     * @param operation
     * @param model
     * @return
     */
    @RequestMapping(value = "/search", method = {RequestMethod.POST })
    public String searchList(Locale locale,
            @ModelAttribute("form") RoleForm form,
            @RequestParam(required = false) String operation, Model model) {

        log.debug("in searchList method");

        System.out.println("myOperation  "+operation);
       
        // Calculate next page number
        int pageNo = form.getPageNo();

        if (OP_NEXT.equals(operation)) {
            pageNo++;
        } else if (OP_PREVIOUS.equals(operation)) {
            pageNo--;
        }

        pageNo = (pageNo < 1) ? 1 : pageNo;

        form.setPageNo(pageNo);
        
        if(OP_RESET.equalsIgnoreCase(form.getOperation()))
        {
     	   return "redirect:/ctl/Role/search";
        }else
             if(OP_NEW.equalsIgnoreCase(form.getOperation()))
        {
     	   return "redirect:/ctl/Role";
        }else
              if (OP_DELETE.equalsIgnoreCase(operation)) {
            
            	   if(form.getChk_1() != null)
            	  {
                       for (long id : form.getChk_1()) {
            try {
					service.delete(id);
				} catch (RecordNotFoundException e) 
                  {
					log.error("Critical Issue", e);
					e.printStackTrace();
				  }
            }

            String msg = messageSource.getMessage("message.success", null,
                    locale);
            model.addAttribute("success", msg);

        }else
        {
        	
             model.addAttribute("error", "Select Atleast One Record");	
        }
              }
        // Get search attributes
        RoleDTO dto = (RoleDTO) form.getDto();

        if(OP_DELETE.equalsIgnoreCase(operation))
        {
        	dto=null;
        }
         
        List list=service.search(dto, pageNo, form.getPageSize());
        model.addAttribute("list",list);

  		if(list.size()==0 && !OP_DELETE.equalsIgnoreCase(operation)){
  			model.addAttribute("error","No Record Found ");
  		}
          
        return "RoleList";
    }

}

