package com.sunilos.proj0.ctl;

import java.util.List;
import java.util.Locale;

import javax.validation.Valid;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.sunilos.proj0.dto.RoleDTO;
import com.sunilos.proj0.dto.TimeTableDTO;
import com.sunilos.proj0.exception.RecordNotFoundException;
import com.sunilos.proj0.form.RoleForm;
import com.sunilos.proj0.form.TimeTableForm;
import com.sunilos.proj0.service.CollegeServiceInt;
import com.sunilos.proj0.service.CourseServiceInt;
import com.sunilos.proj0.service.SubjectServiceInt;
import com.sunilos.proj0.service.TimeTableServiceInt;

/**
 * Contains navigation logics for TimeTable and TimeTable List usecases.
 * 
 * @author OB Server
 * @version 1.0
 * @Copyright (c) OB Server
 */

@Controller
@RequestMapping(value="/ctl/TimeTable")
public class TimeTableCtl extends BaseCtl{

	/**
     * Logger object
     */
	private static Logger log=Logger.getLogger(TimeTableCtl.class);
	
	@Autowired
	TimeTableServiceInt service;
	
	@Autowired
	MessageSource messageSource;
	
	@Autowired
	CourseServiceInt courseService;
	
	@Autowired
	SubjectServiceInt subjectService;
	
	/**
     * Preload Course List
     * Preload Subject List
     * 
     */
	@Override
	public void preload(Model model) {
		
		log.debug("FacultyCtl preload start");
		
		System.out.println("Preload method ");
		
		List list=courseService.search(null);
		model.addAttribute("courseList", list);
				
		List list2=subjectService.search(null);
		model.addAttribute("subjectList", list2);
		
		List list3=service.search(null, 0, 0);
		model.addAttribute("timetableList", list3);
		log.debug("FacultyCtl preload End");
	}
	/**
	 * TimeTable Display View
	 * 
	 * @param id
	 * @param form
	 * @param model
	 * @return
	 */
	@RequestMapping(method=RequestMethod.GET)
	public String display(@RequestParam(required=false) Long id, @ModelAttribute("form") TimeTableForm form,Model model)
	{
		log.debug("TimeTableCtl display start");
		
		if(id!=null && id>0)
		{
			TimeTableDTO dto=service.findById(id);
			form.populate(dto);
		}
		log.debug("TimeTableCtl display End");
		return "TimeTable";
	}
	
	/**
	 * TimeTable Submit View
	 * 
	 * @param locale
	 * @param operation
	 * @param form
	 * @param bindingResult
	 * @param model
	 * @return
	 */
	@RequestMapping(method=RequestMethod.POST)
	public String submit(Locale locale,@RequestParam String operation,
		@ModelAttribute("form") @Valid TimeTableForm form,BindingResult bindingResult,Model model	)
	{
		log.debug("TimeTableCtl Submit start");
		
		if(OP_RESET.equalsIgnoreCase(operation))
		{
			return "redirect:/ctl/TimeTable";
		}
		 if(OP_CANCEL.equalsIgnoreCase(form.getOperation()))
	        {
	     	   return "redirect:/ctl/TimeTable/search";
	        }
		if(bindingResult.hasErrors())
		{
			return "TimeTable";
		}
		
		try
		{
		if(OP_SAVE.equalsIgnoreCase(operation) || OP_UPDATE.equalsIgnoreCase(operation))
		{
			TimeTableDTO dto=(TimeTableDTO)form.getDto();
			
			if(dto.getId()>0)
			{
				service.update(dto);
			}else
			{
				service.add(dto);
			}
			String msg=messageSource.getMessage("message.success", null,locale);
			model.addAttribute("success", msg);
		}else if(OP_DELETE.equalsIgnoreCase(operation))
		{
			service.delete(form.getId());
			
			String msg = messageSource.getMessage("message.success", null,
                    locale);
            model.addAttribute("success", msg);

            return "redirect:/ctl/TimeTable/search";
		}
		}catch(Exception e)
		{
			log.error("Critical Issue", e);
			model.addAttribute("error",""+e.getMessage());
		}
		
		log.debug("TimeTableCtl Submit End");
		return "TimeTable";
	}

	/**
     * Displays TimeTable List view.
     * 
     * @param form
     * @param model
     * @return
     */
    @RequestMapping(value = "/search", method = RequestMethod.GET)
    public String searchList(@ModelAttribute("form") TimeTableForm form, Model model) {
        model.addAttribute("list",
                service.search(null, form.getPageNo(), form.getPageSize()));
        return "TimeTableList";
    }

    /**
     * Submits TimeTable List data.
     * 
     * @param locale
     * @param form
     * @param operation
     * @param model
     * @return
     */
    @RequestMapping(value = "/search", method = {RequestMethod.POST })
    public String searchList(Locale locale,
            @ModelAttribute("form") TimeTableForm form,
            @RequestParam(required = false) String operation, Model model) {

        log.debug("in searchList method");
 
        // Calculate next page number
        int pageNo = form.getPageNo();

        if (OP_NEXT.equals(operation)) {
            pageNo++;
        } else if (OP_PREVIOUS.equals(operation)) {
            pageNo--;
        }

        pageNo = (pageNo < 1) ? 1 : pageNo;

        form.setPageNo(pageNo);
        if(OP_RESET.equalsIgnoreCase(form.getOperation()))
        {
     	   return "redirect:/ctl/TimeTable/search";
        }else
             if(OP_NEW.equalsIgnoreCase(form.getOperation()))
        {
     	   return "redirect:/ctl/TimeTable";
        }else
              if (OP_DELETE.equalsIgnoreCase(operation)) {
            
            	   if(form.getChk_1() != null)
            	  {
                       for (long id : form.getChk_1()) {
            try {
					service.delete(id);
				} catch (RecordNotFoundException e) 
                  {
					log.error("Critical Issue", e);
					e.printStackTrace();
				  }
            }

            String msg = messageSource.getMessage("message.success", null,
                    locale);
            model.addAttribute("success", msg);

        }else
        {
        	
             model.addAttribute("error", "Select Atleast One Record");	
        }
              }
        // Get search attributes
        TimeTableDTO dto = (TimeTableDTO) form.getDto();

        if(OP_DELETE.equalsIgnoreCase(operation))
        {
        	dto=null;
        }
         
        List list=service.search(dto, pageNo, form.getPageSize());
        model.addAttribute("list",list);

  		if(list.size()==0 && !OP_DELETE.equalsIgnoreCase(operation)){
  			model.addAttribute("error","No Record Found ");
  		}
          
        log.debug("in searchList method End");
        
        return "TimeTableList";
    }


	
}
