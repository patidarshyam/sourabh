package com.sunilos.proj0.dao;

import java.util.Date;
import java.util.List;

import com.sunilos.proj0.dto.TimeTableDTO;

public interface TimeTableDAOInt{


	/**
	 *  Add a TimeTable
	 * @param dto
	 * @return long
	 */
	public long add(TimeTableDTO dto);

	/**
	 * Update a TimeTable
	 * @param dto
	 */
	public void update(TimeTableDTO dto);

	/**
	 * Delete a TimeTable
	 * @param dto
	 */
	public void delete(TimeTableDTO dto);

	/**
	 * Find TimeTable by Primary Key.
	 * @param pk
	 * @return TimeTableDTO
	 */
	public TimeTableDTO findByPK(long pk);

	/**
	 * Find TimeTable by CourseNameSubjectName
	 * @param CourseName,SubjectName
	 * @return TimeTableDTO
	 */
	public TimeTableDTO findByCourseNameSubjectName(String courseName,String subjectName);
	
	/**
	 * Find TimeTable by CourseNameExamDate
	 * @param CourseName,ExamDate
	 * @return TimeTableDTO
	 */
	public TimeTableDTO findByCourseNameExamDate(String courseName,Date examDate);
	

	/**
	 * Search TimeTable with pagination
	 * @param dto
	 * @param pageNo
	 * @param pageSize
	 * @return
	 */
	public List<TimeTableDTO> search(TimeTableDTO dto,int pageNo,int pageSize);

	/**
	 * Search TimeTable
	 * @param dto
	 * @return
	 */
	public List<TimeTableDTO> search(TimeTableDTO dto);

}
