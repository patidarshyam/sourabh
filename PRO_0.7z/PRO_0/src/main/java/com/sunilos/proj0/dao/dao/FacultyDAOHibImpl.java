package com.sunilos.proj0.dao;

import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.sunilos.proj0.dto.FacultyDTO;
/**
 * Hibernate implementation of Faculty DAO.
 * 
 * @author OB server
 * @version 1.0
 * @Copyright (c) SunilOS
 * 
 */
@Repository("facultyDAO")
public class FacultyDAOHibImpl implements FacultyDAOInt{

	@Autowired
	SessionFactory sessionFactory=null;
	
	public static Logger log=Logger.getLogger(FacultyDAOHibImpl.class);
	/**
	 * Add Faculty
	 *
	 */
	public long add(FacultyDTO dto) {

		log.debug("FacultyDAOHibImpl add starts");
		long pk=(Long)sessionFactory.getCurrentSession().save(dto);
		log.debug("FacultyDAOHibImpl add end");
		return pk;
	}
	/**
	 * Update Faculty
	 *
	 */
	public void update(FacultyDTO dto) {
		
		log.debug("FacultyDAOHibImpl Update starts");
		sessionFactory.getCurrentSession().merge(dto);
		log.debug("FacultyDAOHibImpl Update End");
		
	}
	/**
	 *Delete Faculty
	 *
	 */
	public void delete(FacultyDTO dto) {
		
		log.debug("FacultyDAOHibImpl Delete starts");
		sessionFactory.getCurrentSession().delete(dto);
		log.debug("FacultyDAOHibImpl Delete End");
		
	}
	/**
	 * find by Pk
	 *
	 */
	public FacultyDTO findByPK(long pk) {

        log.debug("FacultyDAOHibImpl findByPK starts");
		
		FacultyDTO dto=null;
		dto=(FacultyDTO)sessionFactory.openSession().get(FacultyDTO.class, pk);
		
		log.debug("FacultyDAOHibImpl findByPK End");
		return dto;
	}
	/**
	 * find Faculty by Login
	 *
	 */
	public FacultyDTO findByLogin(String email) {

       log.debug("FacultyDAOHibImpl findByName starts");
		
		FacultyDTO dto=null;
		Criteria criteria=sessionFactory.getCurrentSession().createCriteria(FacultyDTO.class);
		List list=criteria.add(Restrictions.like("email",email)).list();
		
		if(list.size()==1)
		{
			dto=(FacultyDTO)list.get(0);
		}
		log.debug("FacultyDAOHibImpl findByName End");
		return dto;

	}
	  /**
     * Search Faculty
     * 
     * @return list : List of Faculty
     * @param dto
     *            : Search Parameters
     */
	public List<FacultyDTO> search(FacultyDTO dto, int pageNo, int pageSize) {

       log.debug("FacultyDAOHibImpl Search starts");
		
		Criteria criteria=sessionFactory.getCurrentSession().createCriteria(FacultyDTO.class);
		
		/*if(dto.getId()>0)
		{
			criteria.add(Restrictions.eq("id", dto.getId()));
		}*/
		if(dto!=null)
		{
		if(dto.getFirstName()!=null && dto.getFirstName().length()>0)
		{
			criteria.add(Restrictions.like("firstName", dto.getFirstName()+ "%"));
		}
		if(dto.getLastName()!=null && dto.getLastName().length()>0)
		{
		   criteria.add(Restrictions.like("lastName", dto.getLastName()+ "%"));
		}
		if(dto.getEmail()!=null && dto.getEmail().length()>0)
		{
			criteria.add(Restrictions.like("email", dto.getEmail()+ "%"));
		}
		if(dto.getCollegeName()!=null && dto.getCollegeName().length()>0)
		{
		   criteria.add(Restrictions.eq("collegeName", dto.getCollegeName()));
		}
		if(dto.getCourseName()!=null && dto.getCourseName().length()>0)
		{
		   criteria.add(Restrictions.like("courseName", dto.getCourseName()+ "%"));
		}
		if(dto.getCollegeId()>0)
		{
			criteria.add(Restrictions.eq("collegeId", dto.getCollegeId()));
		}
		}
		if(pageSize>0)
		{
			criteria.setFirstResult((pageNo-1)*pageSize);
			criteria.setMaxResults(pageSize);
		}
		List<FacultyDTO> list=criteria.list();
		log.debug("FacultyDAOHibImpl Search End");
		return list;

	}
	  /**
     * Search Course
     * 
     * @return list : List of Course
     * @param dto
     *            : Search Parameters
     */
	public List<FacultyDTO> search(FacultyDTO dto) {

		return search(dto, 0, 0);
	}

}
