package com.sunilos.proj0.dao;

import java.util.List;

import com.sunilos.proj0.dto.FacultyDTO;

/**
 * 
 * Faculty DAO interface.
 * 
 * @author OB Server
 * @version 1.0
 * @Copyright (c) OB Server
 */
public interface FacultyDAOInt {

/**
 *  Add a Faculty
 * @param dto
 * @return long
 */
public long add(FacultyDTO dto);

/**
 * Update a Faculty
 * @param dto
 */
public void update(FacultyDTO dto);

/**
 * Delete a Faculty
 * @param dto
 */
public void delete(FacultyDTO dto);

/**
 * Find Faculty by Primary Key.
 * @param pk
 * @return FacultyDTO
 */
public FacultyDTO findByPK(long pk);

/**
 * Find Faculty by Login
 * @param name
 * @return FacultyDTO
 */
public FacultyDTO findByLogin(String name);

/**
 * Search Faculty with pagination
 * @param dto
 * @param pageNo
 * @param pageSize
 * @return
 */
public List<FacultyDTO> search(FacultyDTO dto,int pageNo,int pageSize);

/**
 * Search Faculty
 * @param dto
 * @return
 */
public List<FacultyDTO> search(FacultyDTO dto);
}

