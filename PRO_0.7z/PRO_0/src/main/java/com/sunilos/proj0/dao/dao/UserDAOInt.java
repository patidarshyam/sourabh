package com.sunilos.proj0.dao;

import java.util.List;

import org.springframework.dao.DataAccessException;

import com.sunilos.proj0.dto.UserDTO;

/**
 * User DAO Interface provides abstract methods of CRUD operations.
 * Implementation will be done by JDBC, Hibrenate or JPA.
 * 
 * All methods propagate unchecked DataAccessException. It is a generic
 * exception handling provided by Spring-DAO.
 * 
 * If DataAccessException is propagated from a method then declarative
 * transaction is rolled back by Spring AOP.
 * 
 * @version 1.0
 * @since 1 Jan 2015
 * @author Sunil Sahu
 * @Copyright (c) Sunil Sahu
 * @url www.sunilbooks.com
 */

public interface UserDAOInt {

/**
 * Add User
 * 
 * @param dto
 * @return
 * @throws DataAccessException
 */
public long add(UserDTO dto) throws DataAccessException;

/**
 * Update User
 * 
 * @param dto
 * @throws DataAccessException
 */
public void update(UserDTO dto) throws DataAccessException;

/**
 * Delete User
 * 
 * @param dto
 * @throws DataAccessException
 */
public void delete(UserDTO dto) throws DataAccessException;

/**
 * find User By Pk
 * 
 * @param pk
 * @return
 * @throws DataAccessException
 */
public UserDTO findByPK(long pk) throws DataAccessException;

/**
 * find User By Login 
 * 
 * @param login
 * @return
 * @throws DataAccessException
 */
public UserDTO findByLogin(String login)throws DataAccessException;

/**
 * Search User with pagination
 * 
 * @param dto
 * @param pageNo
 * @param pageSize
 * @return List of User
 * @throws DataAccessException
 */
public List<UserDTO> search(UserDTO dto,int pageNo,int pageSize) throws DataAccessException;

/**
 * Search User
 * 
 * @param dto
 * @return
 * @throws DataAccessException
 */
public List<UserDTO> search(UserDTO dto)throws DataAccessException;

}
