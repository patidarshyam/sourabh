package com.sunilos.proj0.dao;

import java.util.List;

import com.sunilos.proj0.dto.RoleDTO;

/**
 * 
 * Role DAO interface.
 * 
 * @author OB Server
 * @version 1.0
 * @Copyright (c) OB Server
 */

public interface RoleDAOInt {

/**
 *  Add a Role
 * @param dto
 * @return long
 */
public long add(RoleDTO dto);

/**
 * Update a Role
 * @param dto
 */
public void update(RoleDTO dto);

/**
 * Delete a Role
 * @param dto
 */
public void delete(RoleDTO dto);

/**
 * Find Role by Primary Key.
 * @param pk
 * @return RoleDTO
 */
public RoleDTO findByPK(long pk);

/**
 * Find Role by name
 * @param name
 * @return RoleDTO
 */
public RoleDTO findByName(String name);

/**
 * Search Role with pagination
 * @param dto
 * @param pageNo
 * @param pageSize
 * @return
 */
public List search(RoleDTO dto,int pageNo,int pageSize);

/**
 * Search Role
 * @param dto
 * @return
 */
public List search(RoleDTO dto);
}
