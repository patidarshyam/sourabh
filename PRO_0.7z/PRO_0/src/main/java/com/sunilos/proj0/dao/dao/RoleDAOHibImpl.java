package com.sunilos.proj0.dao;

import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.mchange.v2.c3p0.ComboPooledDataSource;
import com.sunilos.proj0.dto.RoleDTO;

/**
 * Hibernate implementation of Role DAO.
 * 
 * @author OB Server
 * @version 1.0
 * @Copyright (c) OB Server
 * 
 */

@Repository
public class RoleDAOHibImpl implements RoleDAOInt{

	@Autowired
	private SessionFactory sessionFactory;
	
	@Autowired
	private ComboPooledDataSource ds;
	
	public static Logger log=Logger.getLogger(RoleDAOHibImpl.class);
	/**
	 * Add Role
	 *
	 */
	public long add(RoleDTO dto) {
		
		log.debug("RoleDAOHibImpl add starts");
		System.out.println("Dao RoleName  "+dto.getRoleName());
		
		System.out.println( sessionFactory);
		Long pk= (Long) sessionFactory.getCurrentSession().save(dto);
		
		log.debug("RoleDAOHibImpl add end");
		return pk;
	}
	/**
	 * Update Role
	 *
	 */
	public void update(RoleDTO dto) {
		log.debug("RoleDAOHibImpl Update starts");
		sessionFactory.getCurrentSession().merge(dto);
		log.debug("RoleDAOHibImpl Update End");
		
	}
	/**
	 *Delete Role
	 *
	 */
	public void delete(RoleDTO dto) {
		log.debug("RoleDAOHibImpl Delete starts");
		sessionFactory.getCurrentSession().delete(dto);
		log.debug("RoleDAOHibImpl Delete End");
	}
	/**
	 * find by Pk
	 *
	 */
	public RoleDTO findByPK(long pk) {
		
		log.debug("RoleDAOHibImpl findByPK starts");
		
		RoleDTO dto=null;
		dto=(RoleDTO)sessionFactory.openSession().get(RoleDTO.class, pk);
		
		log.debug("RoleDAOHibImpl findByPK End");
		return dto;
	}
	/**
	 * find Role by Name
	 *
	 */
	public RoleDTO findByName(String name) {
		log.debug("RoleDAOHibImpl findByName starts");
		System.out.println("hvcccccccccccccddddddddhhhhhhhhhhhhhhhhhhh");
		RoleDTO dto=null;
		Criteria criteria=sessionFactory.getCurrentSession().createCriteria(RoleDTO.class);
		criteria.add(Restrictions.like("roleName", name));
		List list=criteria.list();
		
		if(list.size()>0)
		{
			dto=(RoleDTO)list.get(0);
		}else
		{
			dto=null;
		}
		log.debug("RoleDAOHibImpl findByName End");
		return dto;
	}

	 /**
    * Search Role with pagination
    * 
    * @return list : List of Role
    * @param dto
    *            : Search Parameters
    * @param pageNo
    *            : Current Page No.
    * @param pageSize
    *            : Size of Page
    * 
    */
	public List<RoleDTO> search(RoleDTO dto, int pageNo, int pageSize) {
		
		log.debug("RoleDAOHibImpl Search starts");
		
		Criteria criteria=sessionFactory.getCurrentSession().createCriteria(RoleDTO.class);
		
		System.out.println("aaaaaaaaaaaaaaaaa");
		if(dto!=null)
		{
			System.out.println("0000000000");
		/*if(dto.getId()>0)
		{
			System.out.println("aaaaaaaaa11111111111");
			criteria.add(Restrictions.eq("id", dto.getId()));
		}*/
		if(dto.getRoleName()!=null && dto.getRoleName().length()>0)
		{System.out.println("aaaaaaaaaa222222222");
			criteria.add(Restrictions.like("roleName", dto.getRoleName()+ "%"));
		}
		if(dto.getRoleDescription()!=null && dto.getRoleDescription().length()>0)
		{System.out.println("aaaaaaaaa333333333333");
		   criteria.add(Restrictions.like("roleDescription", dto.getRoleDescription()+ "%"));
		}
		}
		if(pageSize>0)
		{
			criteria.setFirstResult((pageNo-1)*pageSize);
			criteria.setMaxResults(pageSize);
		}
		List<RoleDTO> list=criteria.list();
		log.debug("RoleDAOHibImpl Search End");
		return list;
	}

	  /**
   * Search Role
   * 
   * @return list : List of Role
   * @param dto
   *            : Search Parameters
   */
	public List<RoleDTO> search(RoleDTO dto) {
		
		return search(dto, 0, 0);
	}

}
